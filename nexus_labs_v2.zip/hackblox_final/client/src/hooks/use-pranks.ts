import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Create Prank Hook
type CreatePrankInput = z.infer<typeof api.pranks.create.input>;
type PrankResponse = z.infer<typeof api.pranks.create.responses[201]>;

export function useCreatePrank() {
  return useMutation({
    mutationFn: async (data: CreatePrankInput) => {
      const validated = api.pranks.create.input.parse(data);
      const res = await fetch(api.pranks.create.path, {
        method: api.pranks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400 || res.status === 401) {
          const error = await res.json();
          throw new Error(error.message || "Failed to create prank link");
        }
        throw new Error("An unexpected error occurred");
      }

      return api.pranks.create.responses[201].parse(await res.json());
    },
  });
}

// Get Prank Hook
type GetPrankResponse = z.infer<typeof api.pranks.get.responses[200]>;

export function usePrank(id: number) {
  return useQuery({
    queryKey: [api.pranks.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.pranks.get.path, { id });
      const res = await fetch(url);
      
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to load prank");
      
      return api.pranks.get.responses[200].parse(await res.json());
    },
    enabled: !isNaN(id),
  });
}

// Trigger Prank Hook
type TriggerPrankInput = z.infer<typeof api.pranks.trigger.input>;

export function useTriggerPrank() {
  return useMutation({
    mutationFn: async ({ id, username }: { id: number } & TriggerPrankInput) => {
      const url = buildUrl(api.pranks.trigger.path, { id });
      const validated = api.pranks.trigger.input.parse({ username });
      
      const res = await fetch(url, {
        method: api.pranks.trigger.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) throw new Error("Failed to trigger sequence");
      return api.pranks.trigger.responses[200].parse(await res.json());
    },
  });
}
