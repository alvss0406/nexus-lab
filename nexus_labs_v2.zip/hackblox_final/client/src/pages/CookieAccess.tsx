import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Copy, Eye, EyeOff, ArrowLeft, Loader2 } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

export default function CookieAccess() {
  const [cookie, setCookie] = useState<string | null>(null);
  const [showCookie, setShowCookie] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const storedCookie = localStorage.getItem("roblox_cookie");
    if (storedCookie) {
      setCookie(storedCookie);
    }
    setIsLoading(false);
  }, []);

  const handleCopyCookie = () => {
    if (cookie) {
      navigator.clipboard.writeText(cookie);
      toast({
        title: "Copiado!",
        description: "Cookie copiado para a área de transferência",
      });
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-purple-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-purple-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="COOKIE ACCESS"
              className="text-3xl md:text-4xl font-black text-purple-500 text-glow"
            />
            <p className="text-purple-500/60 text-sm mt-1">
              Visualize seu .ROBLOSECURITY ativo
            </p>
          </div>
        </div>

        {/* Content */}
        {isLoading ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-black/80 border-2 border-purple-500/30 p-8 rounded-lg text-center"
          >
            <Loader2 className="w-8 h-8 text-purple-500 animate-spin mx-auto mb-4" />
            <p className="text-purple-500">Carregando...</p>
          </motion.div>
        ) : !cookie ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-red-500/30 p-8 rounded-lg text-center"
          >
            <h2 className="text-xl font-bold text-red-500 mb-2">
              Nenhuma Sessão Ativa
            </h2>
            <p className="text-red-500/60 mb-6">
              Faça login primeiro para acessar seu cookie
            </p>
            <Link href="/cookie-login">
              <button className="px-6 py-2 bg-red-500/10 border-2 border-red-500 text-red-500 rounded hover:bg-red-500 hover:text-black transition-all">
                Fazer Login
              </button>
            </Link>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Cookie Display */}
            <div className="bg-black/80 border-2 border-purple-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(168,85,247,0.2)]">
              <div className="flex items-center justify-between mb-4">
                <label className="text-xs font-bold text-purple-500 uppercase tracking-wider">
                  .ROBLOSECURITY Cookie
                </label>
                <button
                  onClick={() => setShowCookie(!showCookie)}
                  className="p-2 hover:bg-purple-500/20 rounded transition-all"
                >
                  {showCookie ? (
                    <EyeOff className="w-5 h-5 text-purple-500" />
                  ) : (
                    <Eye className="w-5 h-5 text-purple-500" />
                  )}
                </button>
              </div>

              <div className="bg-purple-900/10 border-2 border-purple-500/30 p-4 rounded font-mono text-sm break-all text-purple-400 mb-4 min-h-24 flex items-center">
                {showCookie ? cookie : "•".repeat(Math.min(cookie.length, 50))}
              </div>

              <NeonButton
                onClick={handleCopyCookie}
                className="w-full bg-purple-500/10 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-black"
              >
                <Copy className="w-4 h-4 mr-2 inline" />
                COPIAR COOKIE
              </NeonButton>
            </div>

            {/* Security Warning */}
            <div className="bg-yellow-900/20 border-2 border-yellow-500/30 p-4 rounded">
              <p className="text-yellow-500 text-sm">
                ⚠️ <strong>Aviso de Segurança:</strong> Nunca compartilhe seu
                cookie com ninguém! Ele dá acesso completo à sua conta.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
