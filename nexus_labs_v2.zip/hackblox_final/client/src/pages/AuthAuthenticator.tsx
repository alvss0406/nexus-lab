import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Shield, ArrowLeft, Loader2, Copy } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  secret: z.string().min(10, "Secret deve ter pelo menos 10 caracteres"),
});

type FormValues = z.infer<typeof formSchema>;

interface CodeResult {
  code: string;
  expiresIn: number;
}

export default function AuthAuthenticator() {
  const [isLoading, setIsLoading] = useState(false);
  const [codeResult, setCodeResult] = useState<CodeResult | null>(null);
  const [timeLeft, setTimeLeft] = useState(30);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      secret: "",
    },
  });

  // Timer para o código 2FA
  useEffect(() => {
    if (!codeResult) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setCodeResult(null);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [codeResult]);

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    setTimeLeft(30);
    try {
      const response = await fetch("/api/roblox/2fa-generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret: data.secret }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao gerar código");
      }

      const result = await response.json();
      setCodeResult(result);

      toast({
        title: "Código Gerado!",
        description: "Código 2FA gerado com sucesso",
      });
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao gerar código",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyCode = () => {
    if (codeResult) {
      navigator.clipboard.writeText(codeResult.code);
      toast({
        title: "Copiado!",
        description: "Código copiado para a área de transferência",
      });
    }
  };

  const progressPercent = (timeLeft / 30) * 100;

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(234, 179, 8, .3) 25%, rgba(234, 179, 8, .3) 26%, transparent 27%, transparent 74%, rgba(234, 179, 8, .3) 75%, rgba(234, 179, 8, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(234, 179, 8, .3) 25%, rgba(234, 179, 8, .3) 26%, transparent 27%, transparent 74%, rgba(234, 179, 8, .3) 75%, rgba(234, 179, 8, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-yellow-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-yellow-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="AUTH AUTHENTICATOR"
              className="text-3xl md:text-4xl font-black text-yellow-500 text-glow"
            />
            <p className="text-yellow-500/60 text-sm mt-1">
              Gerador de código 2FA
            </p>
          </div>
        </div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-black/80 border-2 border-yellow-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(234,179,8,0.2)] mb-6"
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-yellow-500 uppercase tracking-wider">
                Secret Key (Base32)
              </label>
              <textarea
                {...form.register("secret")}
                placeholder="Cole sua chave secreta aqui..."
                className="w-full h-24 bg-yellow-900/10 border-2 border-yellow-500/30 rounded px-4 py-3 text-yellow-400 placeholder:text-yellow-500/20 focus:outline-none focus:border-yellow-500 focus:shadow-[0_0_15px_rgba(234,179,8,0.3)] transition-all font-mono text-sm"
              />
              {form.formState.errors.secret && (
                <p className="text-red-500 text-xs font-mono">
                  {form.formState.errors.secret.message}
                </p>
              )}
            </div>

            <NeonButton
              type="submit"
              disabled={isLoading}
              className="w-full bg-yellow-500/10 border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                  Gerando...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4 mr-2 inline" />
                  GERAR CÓDIGO
                </>
              )}
            </NeonButton>
          </form>
        </motion.div>

        {/* Code Display */}
        {codeResult && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/80 border-2 border-yellow-500 p-8 rounded-lg text-center shadow-[0_0_30px_rgba(234,179,8,0.3)]"
          >
            <p className="text-yellow-500/60 text-xs uppercase font-bold mb-4">
              Código 2FA
            </p>

            <div className="bg-yellow-900/20 border-2 border-yellow-500/30 p-6 rounded-lg mb-4">
              <p className="text-5xl font-bold text-yellow-400 font-mono tracking-widest">
                {codeResult.code}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="w-full h-2 bg-yellow-900/20 border border-yellow-500/30 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.8)]"
                  initial={{ width: "100%" }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 1, ease: "linear" }}
                />
              </div>
              <p className="text-yellow-500/60 text-xs mt-2">
                Expira em {timeLeft}s
              </p>
            </div>

            <NeonButton
              onClick={copyCode}
              className="w-full bg-yellow-500/10 border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black mb-4"
            >
              <Copy className="w-4 h-4 mr-2 inline" />
              COPIAR CÓDIGO
            </NeonButton>

            <NeonButton
              onClick={() => setCodeResult(null)}
              className="w-full bg-transparent border-yellow-500/50 text-yellow-500/60 hover:text-yellow-500"
            >
              Gerar Novo
            </NeonButton>
          </motion.div>
        )}
      </div>
    </div>
  );
}
