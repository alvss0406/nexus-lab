import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { api } from "@shared/routes";
import { NeonButton } from "@/components/NeonButton";
import { useToast } from "@/hooks/use-toast";
import { Ticket, AccessKey, DiscordNick } from "@shared/schema";
import { 
  Key, 
  Ticket as TicketIcon, 
  Plus, 
  ShieldCheck, 
  MessageSquare,
  Clock
} from "lucide-react";

export default function Admin() {
  const { toast } = useToast();
  const isStaff = localStorage.getItem("hackblox_is_staff") === "true";
  const masterKey = localStorage.getItem("hackblox_token") || "";

  const { data: nicks } = useQuery<DiscordNick[]>({
    queryKey: ["/api/discord-nicks"],
  });

  const { data: keys } = useQuery<AccessKey[]>({
    queryKey: [api.admin.keys.list.path],
    queryFn: async () => {
      const res = await fetch(api.admin.keys.list.path, {
        headers: { "x-master-key": masterKey }
      });
      if (!res.ok) throw new Error("Unauthorized");
      return res.json();
    }
  });

  const { data: tickets } = useQuery<Ticket[]>({
    queryKey: [api.admin.tickets.list.path],
    queryFn: async () => {
      const res = await fetch(api.admin.tickets.list.path, {
        headers: { "x-master-key": masterKey }
      });
      if (!res.ok) throw new Error("Unauthorized");
      return res.json();
    }
  });

  const createKey = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.admin.keys.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ masterKey })
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.admin.keys.list.path] });
      toast({ title: "New access key generated" });
    }
  });

  const [ticketCode, setTicketCode] = useState("");
  const createTicket = useMutation({
    mutationFn: async ({ code, type }: { code: string, type: string }) => {
      const res = await fetch(api.admin.tickets.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ masterKey, code, type })
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.admin.tickets.list.path] });
      setTicketCode("");
      toast({ title: "Ticket created successfully" });
    }
  });

  const [adminPassword, setAdminPassword] = useState("");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "2012064Pr") {
      setIsAdminAuthenticated(true);
      localStorage.setItem("hackblox_token", adminPassword);
    } else {
      toast({ title: "Senha Incorreta", variant: "destructive" });
    }
  };

  if (!isAdminAuthenticated && masterKey !== "2012064Pr") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black font-sans p-4">
        <div className="max-w-[400px] w-full space-y-8">
          <div className="flex flex-col items-center gap-8">
            <div className="w-24 h-24 bg-primary/20 rounded-[2rem] flex items-center justify-center border-2 border-primary/50 shadow-[0_0_30px_rgba(168,85,247,0.2)]">
              <ShieldCheck className="w-12 h-12 text-primary" />
            </div>
            <div className="text-center space-y-2">
              <h1 className="text-4xl font-bold text-white tracking-tight">Admin</h1>
              <p className="text-gray-400 text-sm">Painel de Controle Restrito</p>
            </div>
          </div>
          <form onSubmit={handleAdminAuth} className="space-y-4">
            <input 
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="SENHA MESTRE"
              className="w-full bg-[#111] border border-white/5 rounded-2xl px-6 py-5 text-center text-white text-xl tracking-[0.2em] focus:border-primary/50 focus:outline-none transition-colors"
            />
            <button type="submit" className="w-full bg-primary hover:bg-primary/80 text-white font-semibold py-5 rounded-2xl transition-all">
              DESBLOQUEAR PAINEL
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8 font-mono">
      <div className="flex items-center gap-4 mb-8">
        <ShieldCheck className="w-10 h-10 text-primary" />
        <h1 className="text-3xl font-display uppercase tracking-widest text-glow">Admin Control Center</h1>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Nicks Section */}
        <section className="bg-card/30 p-6 rounded-xl border border-blue-500/20 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-display flex items-center gap-2 text-blue-400">
              <MessageSquare className="w-5 h-5" /> Discord Nicks
            </h2>
          </div>
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {nicks?.map(n => (
              <div key={n.id} className="p-3 bg-black/40 border border-blue-500/10 rounded space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-blue-400 font-bold text-sm">{n.username}</span>
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(n.submittedAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
                  Ticket: {n.ticketCode}
                </div>
              </div>
            ))}
            {(!nicks || nicks.length === 0) && (
              <p className="text-xs text-muted-foreground italic text-center py-4">Nenhum nick enviado ainda.</p>
            )}
          </div>
        </section>

        {/* Tickets Section */}
        <section className="bg-card/30 p-6 rounded-xl border border-secondary/20 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-display flex items-center gap-2 text-glow-green">
              <TicketIcon className="w-5 h-5 text-secondary" /> Entrance Tickets
            </h2>
          </div>
          <div className="flex gap-2">
            <input 
              value={ticketCode}
              onChange={(e) => setTicketCode(e.target.value)}
              placeholder="ENTER NEW TICKET..."
              className="flex-1 bg-black/50 border border-border rounded px-3 py-2 text-sm focus:border-secondary focus:outline-none"
            />
            <NeonButton onClick={() => createTicket.mutate({ code: ticketCode, type: "normal" })} variant="secondary">
              NORMAL
            </NeonButton>
            {masterKey === "2012064Pr" && (
              <NeonButton onClick={() => createTicket.mutate({ code: ticketCode, type: "staff" })} variant="danger">
                STAFF
              </NeonButton>
            )}
          </div>
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {tickets?.map(t => (
              <div key={t.id} className="p-3 bg-black/40 border border-border rounded flex justify-between items-center text-xs">
                <span className={t.isUsed ? "text-muted-foreground" : (t.type === "staff" ? "text-primary font-bold" : "text-secondary")}>
                  {t.code} {t.type === "staff" && "(STAFF)"}
                </span>
                <span className="text-[10px] uppercase">{t.isUsed ? "ACTIVE" : "PENDING"}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
