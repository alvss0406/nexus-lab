import { useState } from "react";
import { useRoute } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, User, Lock, Activity } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { usePrank, useTriggerPrank } from "@/hooks/use-pranks";
import { NeonButton } from "@/components/NeonButton";
import { TerminalWindow } from "@/components/TerminalWindow";
import { GlitchText } from "@/components/GlitchText";
import NotFound from "@/pages/not-found";

// Fake logs for the "hack"
const HACK_LOGS = (username: string) => [
  { id: '1', text: `Target confirmed: ${username}`, type: 'info', delay: 800 },
  { id: '2', text: 'Initializing brute-force sequence...', type: 'info', delay: 1200 },
  { id: '3', text: 'Scanning ports 80, 443, 8080...', type: 'warning', delay: 1500 },
  { id: '4', text: 'Vulnerability detected in ROBLOX_AUTH_V3', type: 'success', delay: 1000 },
  { id: '5', text: 'Injecting SQL payload...', type: 'info', delay: 2000 },
  { id: '6', text: 'Bypassing 2FA via cookie extraction...', type: 'warning', delay: 2500 },
  { id: '7', text: '.ROBLOSECURITY token found!', type: 'success', delay: 1500 },
  { id: '8', text: 'Decrypting local storage data...', type: 'info', delay: 1800 },
  { id: '9', text: 'Extracting Robux balance...', type: 'success', delay: 1200 },
  { id: '10', text: 'Uploading data to remote server...', type: 'warning', delay: 2000 },
  { id: '11', text: 'Cleaning up trace logs...', type: 'info', delay: 1000 },
  { id: '12', text: 'OPERATION SUCCESSFUL. SESSION CAPTURED.', type: 'success', delay: 0 },
] as const;

const formSchema = z.object({
  username: z.string().min(1, "Username is required"),
});

export default function PrankView() {
  const [match, params] = useRoute("/hack/:id");
  const id = parseInt(params?.id || "0");
  
  const { data: prank, isLoading: isPrankLoading, isError } = usePrank(id);
  const triggerPrank = useTriggerPrank();
  
  const [hackState, setHackState] = useState<"idle" | "running" | "complete">("idle");
  const [username, setUsername] = useState("");

  const form = useForm<{ username: string }>({
    resolver: zodResolver(formSchema),
  });

  const onStartHack = (data: { username: string }) => {
    setUsername(data.username);
    setHackState("running");
    
    // Trigger the real webhook in the background
    triggerPrank.mutate({ id, username: data.username });
  };

  const logs = HACK_LOGS(username);

  if (isPrankLoading) return (
    <div className="min-h-screen bg-black flex items-center justify-center font-mono text-green-500">
      INITIALIZING...
    </div>
  );

  if (isError || !prank) return <NotFound />;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-black text-green-500 font-mono scanlines">
      {/* Matrix-like background effect */}
      <div className="fixed inset-0 opacity-10 pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent)', backgroundSize: '50px 50px' }} 
      />

      <div className="w-full max-w-lg relative z-10">
        <AnimatePresence mode="wait">
          {hackState === "idle" && (
            <motion.div
              key="form"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, y: -50 }}
              className="bg-black/80 border border-green-500/30 p-8 rounded-lg shadow-[0_0_50px_rgba(34,197,94,0.15)]"
            >
              <div className="text-center mb-8">
                <Shield className="w-16 h-16 text-green-500 mx-auto mb-4 animate-pulse" />
                <GlitchText text="ROBLOX ACCOUNT RECOVERY" className="text-3xl text-green-500 font-bold mb-2" />
                <p className="text-green-500/60 text-sm">
                  Official Account Recovery Tool v4.2.
                  <br />Enter target username to begin recovery process.
                </p>
              </div>

              <form onSubmit={form.handleSubmit(onStartHack)} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-green-500/80 uppercase tracking-widest flex items-center gap-2">
                    <User className="w-3 h-3" /> Target Username
                  </label>
                  <input
                    {...form.register("username")}
                    placeholder="Enter Roblox Username..."
                    className="w-full bg-green-900/10 border-2 border-green-500/30 rounded px-4 py-3 text-green-400 placeholder:text-green-500/20 focus:outline-none focus:border-green-500 focus:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all font-mono"
                  />
                  {form.formState.errors.username && (
                    <p className="text-red-500 text-xs font-bold">{form.formState.errors.username.message}</p>
                  )}
                </div>

                <NeonButton 
                  type="submit" 
                  variant="secondary" 
                  className="w-full bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
                >
                  START RECOVERY PROCESS
                </NeonButton>
                
                <div className="text-xs text-center text-green-500/40 mt-4">
                  <Lock className="w-3 h-3 inline mr-1" />
                  Secure Connection: 256-bit Encryption Active
                </div>
              </form>
            </motion.div>
          )}

          {hackState === "running" && (
            <motion.div
              key="terminal"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="w-full"
            >
              <div className="mb-4 flex items-center justify-between text-green-500/80 text-xs uppercase tracking-wider font-bold">
                <span>Target: {username}</span>
                <span className="flex items-center gap-2">
                  <Activity className="w-3 h-3 animate-pulse" />
                  Live Connection
                </span>
              </div>
              <TerminalWindow 
                logs={[...logs]} 
                onComplete={() => setHackState("complete")} 
              />
            </motion.div>
          )}

          {hackState === "complete" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-6 bg-black/90 border-2 border-green-500 p-8 rounded-xl shadow-[0_0_50px_rgba(34,197,94,0.4)]"
            >
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto animate-bounce">
                <Lock className="w-10 h-10 text-black" />
              </div>
              
              <div>
                <h2 className="text-3xl font-display font-black text-green-500 mb-2">ACCESS GRANTED</h2>
                <p className="text-green-400 font-mono">
                  Account credentials have been extracted and saved to the secure server.
                </p>
              </div>

              <div className="bg-green-900/20 p-4 rounded border border-green-500/30 text-xs font-mono text-left space-y-2">
                <div className="flex justify-between">
                  <span className="text-green-500/50">USERNAME:</span>
                  <span className="text-green-400">{username}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-500/50">PASSWORD:</span>
                  <span className="text-green-400">********</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-500/50">ROBUX:</span>
                  <span className="text-green-400">14,250</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-500/50">COOKIES:</span>
                  <span className="text-green-400">EXTRACTED</span>
                </div>
              </div>

              <div className="text-xs text-green-500/40 pt-4 border-t border-green-500/20">
                Data sent to webhook successfully. You can close this window.
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
