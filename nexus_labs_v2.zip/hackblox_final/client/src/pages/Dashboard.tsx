import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Lock, LogOut, Key, Users, Search, Shield, Zap, Home, RefreshCw, Share2 } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

interface UserSession {
  userId: string;
  username: string;
  displayName: string;
  created: string;
  isBanned: boolean;
}

export default function Dashboard() {
  const [userSession, setUserSession] = useState<UserSession | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const session = localStorage.getItem("roblox_session");
    if (session) {
      try {
        setUserSession(JSON.parse(session));
      } catch (e) {
        console.error("Erro ao carregar sessão:", e);
      }
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("roblox_session");
    localStorage.removeItem("roblox_cookie");
    setUserSession(null);
    toast({ title: "Desconectado com sucesso!" });
    window.location.href = "/";
  };

  const tools = [
    {
      title: "Cookie Login",
      description: "Faça login com seu .ROBLOSECURITY",
      icon: Lock,
      path: "/cookie-login",
      color: "from-blue-500 to-cyan-500",
    },
    {
      title: "Cookie Access",
      description: "Visualize seu cookie ativo",
      icon: Key,
      path: "/cookie-access",
      color: "from-purple-500 to-pink-500",
    },
    {
      title: "Cookie Refresher",
      description: "Gere um novo cookie válido",
      icon: RefreshCw,
      path: "/cookie-refresher",
      color: "from-cyan-500 to-blue-500",
    },
    {
      title: "Remove Friends",
      description: "Remova todos os amigos",
      icon: Users,
      path: "/remove-friends",
      color: "from-red-500 to-orange-500",
    },
    {
      title: "Account Bypass",
      description: "Modifique configurações",
      icon: Shield,
      path: "/account-bypass",
      color: "from-purple-500 to-indigo-500",
    },
    {
      title: "Search User",
      description: "Busque usuários do Roblox",
      icon: Search,
      path: "/search-user",
      color: "from-green-500 to-emerald-500",
    },
    {
      title: "Auth Authenticator",
      description: "Gerador de código 2FA",
      icon: Shield,
      path: "/auth-authenticator",
      color: "from-yellow-500 to-amber-500",
    },
    {
      title: "Prank Generator",
      description: "Crie links de prank",
      icon: Zap,
      path: "/",
      color: "from-green-500 to-lime-500",
    },
    {
      title: "Nossas Redes",
      description: "Conecte-se conosco",
      icon: Share2,
      path: "/social-networks",
      color: "from-pink-500 to-rose-500",
    },
  ];

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex justify-between items-center mb-12">
          <div>
            <GlitchText
              text="NEXUS LABS"
              className="text-4xl md:text-5xl font-black text-purple-500 text-glow"
            />
            <p className="text-purple-500/60 font-mono italic mt-2">
              Advanced Roblox Management Suite
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/">
              <button className="p-3 bg-card/80 border-2 border-purple-500/50 rounded-full hover:bg-purple-500/20 transition-all shadow-[0_0_20px_rgba(168,85,247,0.3)]">
                <Home className="w-6 h-6 text-purple-500" />
              </button>
            </Link>
            {userSession && (
              <button
                onClick={handleLogout}
                className="p-3 bg-card/80 border-2 border-red-500/50 rounded-full hover:bg-red-500/20 transition-all shadow-[0_0_20px_rgba(239,68,68,0.3)]"
              >
                <LogOut className="w-6 h-6 text-red-500" />
              </button>
            )}
          </div>
        </div>

        {/* User Session Info */}
        {userSession && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-purple-900/20 border-2 border-purple-500/30 p-6 rounded-lg mb-8 shadow-[0_0_30px_rgba(168,85,247,0.2)]"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-purple-500/60 text-xs uppercase">Username</p>
                <p className="text-purple-400 font-bold">{userSession.username}</p>
              </div>
              <div>
                <p className="text-purple-500/60 text-xs uppercase">User ID</p>
                <p className="text-purple-400 font-bold">{userSession.userId}</p>
              </div>
              <div>
                <p className="text-purple-500/60 text-xs uppercase">Display Name</p>
                <p className="text-purple-400 font-bold">{userSession.displayName}</p>
              </div>
              <div>
                <p className="text-purple-500/60 text-xs uppercase">Status</p>
                <p
                  className={`font-bold ${
                    userSession.isBanned
                      ? "text-red-400"
                      : "text-green-400"
                  }`}
                >
                  {userSession.isBanned ? "Banido" : "Ativo"}
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool, index) => {
            const Icon = tool.icon;
            return (
              <motion.div
                key={tool.path}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link href={tool.path}>
                  <a className="block">
                    <div className="bg-black/60 border-2 border-purple-500/30 p-6 rounded-lg hover:border-purple-500 transition-all shadow-[0_0_20px_rgba(168,85,247,0.1)] hover:shadow-[0_0_30px_rgba(168,85,247,0.3)] group cursor-pointer h-full">
                      <div
                        className={`w-12 h-12 rounded-lg bg-gradient-to-br ${tool.color} p-2.5 mb-4 group-hover:scale-110 transition-transform`}
                      >
                        <Icon className="w-full h-full text-white" />
                      </div>
                      <h3 className="text-lg font-bold text-purple-400 mb-2">
                        {tool.title}
                      </h3>
                      <p className="text-purple-500/60 text-sm">
                        {tool.description}
                      </p>
                    </div>
                  </a>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
