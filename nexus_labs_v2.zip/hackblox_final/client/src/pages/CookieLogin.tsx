import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Lock, ArrowLeft, Loader2 } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  cookie: z.string().min(10, "Cookie deve ter pelo menos 10 caracteres"),
});

type FormValues = z.infer<typeof formSchema>;

export default function CookieLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cookie: "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/roblox/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookie: data.cookie }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Cookie inválido");
      }

      const userInfo = await response.json();

      // Armazenar sessão
      localStorage.setItem("roblox_session", JSON.stringify(userInfo));
      localStorage.setItem("roblox_cookie", data.cookie);

      setSuccess(true);
      toast({
        title: "Sucesso!",
        description: `Bem-vindo, ${userInfo.username}!`,
      });

      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 2000);
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao fazer login",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(59, 130, 246, .3) 25%, rgba(59, 130, 246, .3) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, .3) 75%, rgba(59, 130, 246, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(59, 130, 246, .3) 25%, rgba(59, 130, 246, .3) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, .3) 75%, rgba(59, 130, 246, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-blue-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-blue-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="COOKIE LOGIN"
              className="text-3xl md:text-4xl font-black text-blue-500 text-glow"
            />
            <p className="text-blue-500/60 text-sm mt-1">
              Insira seu .ROBLOSECURITY para entrar na conta
            </p>
          </div>
        </div>

        {/* Form */}
        {!success ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-blue-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(59,130,246,0.2)]"
          >
            <div className="flex items-center gap-3 mb-6 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
              <Lock className="w-5 h-5 text-blue-500" />
              <p className="text-blue-400 text-sm">
                Seu cookie será armazenado com segurança
              </p>
            </div>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-blue-500 uppercase tracking-wider">
                  .ROBLOSECURITY Cookie
                </label>
                <textarea
                  {...form.register("cookie")}
                  placeholder="Cole seu .ROBLOSECURITY aqui..."
                  className="w-full h-32 bg-blue-900/10 border-2 border-blue-500/30 rounded px-4 py-3 text-blue-400 placeholder:text-blue-500/20 focus:outline-none focus:border-blue-500 focus:shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all font-mono text-sm"
                />
                {form.formState.errors.cookie && (
                  <p className="text-red-500 text-xs font-mono">
                    {form.formState.errors.cookie.message}
                  </p>
                )}
              </div>

              <NeonButton
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-500/10 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-black"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                    Validando...
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 mr-2 inline" />
                    FAZER LOGIN
                  </>
                )}
              </NeonButton>
            </form>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/80 border-2 border-green-500 p-8 rounded-lg text-center shadow-[0_0_30px_rgba(34,197,94,0.3)]"
          >
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500 animate-pulse">
              <Lock className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-green-500 mb-2">
              Login Bem-Sucedido!
            </h2>
            <p className="text-green-500/60">
              Redirecionando para o dashboard...
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
