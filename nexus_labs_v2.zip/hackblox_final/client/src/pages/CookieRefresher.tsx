import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { RefreshCw, ArrowLeft, Loader2, Copy, Check } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  cookie: z.string().min(10, "Cookie deve ter pelo menos 10 caracteres"),
});

type FormValues = z.infer<typeof formSchema>;

interface RefreshResult {
  oldCookie: string;
  newCookie: string;
  success: boolean;
}

export default function CookieRefresher() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<RefreshResult | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cookie: localStorage.getItem("roblox_cookie") || "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/roblox/refresh-cookie", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookie: data.cookie }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao refreshar cookie");
      }

      const newCookie = await response.json();
      
      setResult({
        oldCookie: data.cookie,
        newCookie: newCookie.cookie,
        success: true,
      });

      // Atualizar localStorage
      localStorage.setItem("roblox_cookie", newCookie.cookie);

      toast({
        title: "Sucesso!",
        description: "Cookie refreshado com sucesso!",
      });
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao refreshar cookie",
        variant: "destructive",
      });
      setResult({
        oldCookie: data.cookie,
        newCookie: "",
        success: false,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyNewCookie = () => {
    if (result?.newCookie) {
      navigator.clipboard.writeText(result.newCookie);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Copiado!",
        description: "Novo cookie copiado para a área de transferência",
      });
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(59, 130, 246, .3) 25%, rgba(59, 130, 246, .3) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, .3) 75%, rgba(59, 130, 246, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(59, 130, 246, .3) 25%, rgba(59, 130, 246, .3) 26%, transparent 27%, transparent 74%, rgba(59, 130, 246, .3) 75%, rgba(59, 130, 246, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-blue-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-blue-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="COOKIE REFRESHER"
              className="text-3xl md:text-4xl font-black text-blue-500 text-glow"
            />
            <p className="text-blue-500/60 text-sm mt-1">
              Gere um novo cookie válido
            </p>
          </div>
        </div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-900/20 border-2 border-blue-500/30 p-4 rounded-lg mb-6"
        >
          <p className="text-blue-400 text-sm">
            ℹ️ O Cookie Refresher gera um novo `.ROBLOSECURITY` válido a partir de um antigo, evitando que ele expire.
          </p>
        </motion.div>

        {/* Form or Result */}
        {!result ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-blue-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(59,130,246,0.2)]"
          >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-blue-500 uppercase tracking-wider">
                  Cookie Antigo
                </label>
                <textarea
                  {...form.register("cookie")}
                  placeholder="Cole seu .ROBLOSECURITY aqui..."
                  className="w-full h-24 bg-blue-900/10 border-2 border-blue-500/30 rounded px-4 py-3 text-blue-400 placeholder:text-blue-500/20 focus:outline-none focus:border-blue-500 focus:shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all font-mono text-sm"
                />
                {form.formState.errors.cookie && (
                  <p className="text-red-500 text-xs font-mono">
                    {form.formState.errors.cookie.message}
                  </p>
                )}
              </div>

              <NeonButton
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-500/10 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-black"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                    Refreshando...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 inline" />
                    REFRESH COOKIE
                  </>
                )}
              </NeonButton>
            </form>
          </motion.div>
        ) : result.success ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            {/* Success Box */}
            <div className="bg-black/80 border-2 border-green-500 p-8 rounded-lg text-center shadow-[0_0_30px_rgba(34,197,94,0.3)]">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500 animate-pulse">
                <Check className="w-8 h-8 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-green-500 mb-2">
                Refresh Bem-Sucedido!
              </h2>
              <p className="text-green-500/60 mb-6">
                Seu novo cookie foi gerado com sucesso
              </p>
            </div>

            {/* New Cookie Display */}
            <div className="bg-black/80 border-2 border-blue-500/30 p-6 rounded-lg">
              <p className="text-blue-500/60 text-xs uppercase font-bold mb-3">
                Novo Cookie
              </p>
              <div className="bg-blue-900/10 border-2 border-blue-500/30 p-4 rounded font-mono text-sm break-all text-blue-400 mb-4 max-h-32 overflow-y-auto">
                {result.newCookie}
              </div>
              <NeonButton
                onClick={copyNewCookie}
                className="w-full bg-blue-500/10 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-black"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 mr-2 inline" />
                    COPIADO!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2 inline" />
                    COPIAR NOVO COOKIE
                  </>
                )}
              </NeonButton>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <NeonButton
                onClick={() => setResult(null)}
                className="flex-1 bg-blue-500/10 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-black"
              >
                Refreshar Novamente
              </NeonButton>
              <Link href="/dashboard" className="flex-1">
                <button className="w-full px-6 py-3 bg-purple-500/10 border-2 border-purple-500 text-purple-500 rounded hover:bg-purple-500 hover:text-black transition-all font-mono font-bold">
                  Voltar ao Dashboard
                </button>
              </Link>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/80 border-2 border-red-500 p-8 rounded-lg text-center shadow-[0_0_30px_rgba(239,68,68,0.3)]"
          >
            <h2 className="text-2xl font-bold text-red-500 mb-2">
              Erro no Refresh
            </h2>
            <p className="text-red-500/60 mb-6">
              Não foi possível gerar um novo cookie. O cookie pode estar inválido ou expirado.
            </p>
            <NeonButton
              onClick={() => setResult(null)}
              className="w-full bg-red-500/10 border-red-500 text-red-500 hover:bg-red-500 hover:text-black"
            >
              Tentar Novamente
            </NeonButton>
          </motion.div>
        )}
      </div>
    </div>
  );
}
