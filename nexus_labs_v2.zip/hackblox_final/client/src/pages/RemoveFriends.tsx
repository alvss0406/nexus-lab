import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Users, ArrowLeft, Loader2, AlertTriangle } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  cookie: z.string().min(10, "Cookie deve ter pelo menos 10 caracteres"),
});

type FormValues = z.infer<typeof formSchema>;

export default function RemoveFriends() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ removed: number; message: string } | null>(null);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cookie: localStorage.getItem("roblox_cookie") || "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/roblox/remove-friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookie: data.cookie }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao remover amigos");
      }

      const data_result = await response.json();
      setResult(data_result);

      toast({
        title: "Sucesso!",
        description: `${data_result.removed} amigo(s) removido(s)!`,
      });
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao remover amigos",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(239, 68, 68, .3) 25%, rgba(239, 68, 68, .3) 26%, transparent 27%, transparent 74%, rgba(239, 68, 68, .3) 75%, rgba(239, 68, 68, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(239, 68, 68, .3) 25%, rgba(239, 68, 68, .3) 26%, transparent 27%, transparent 74%, rgba(239, 68, 68, .3) 75%, rgba(239, 68, 68, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-red-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-red-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="REMOVE FRIENDS"
              className="text-3xl md:text-4xl font-black text-red-500 text-glow"
            />
            <p className="text-red-500/60 text-sm mt-1">
              Remova todos os amigos da sua conta
            </p>
          </div>
        </div>

        {/* Warning */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-900/20 border-2 border-red-500/30 p-4 rounded-lg mb-6 flex gap-3"
        >
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-500 font-bold text-sm">⚠️ Ação Irreversível</p>
            <p className="text-red-500/60 text-xs mt-1">
              Esta ação removerá TODOS os seus amigos. Isso não pode ser desfeito.
            </p>
          </div>
        </motion.div>

        {/* Form or Result */}
        {!result ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-red-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(239,68,68,0.2)]"
          >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-red-500 uppercase tracking-wider">
                  .ROBLOSECURITY Cookie
                </label>
                <textarea
                  {...form.register("cookie")}
                  placeholder="Cole seu .ROBLOSECURITY aqui..."
                  className="w-full h-24 bg-red-900/10 border-2 border-red-500/30 rounded px-4 py-3 text-red-400 placeholder:text-red-500/20 focus:outline-none focus:border-red-500 focus:shadow-[0_0_15px_rgba(239,68,68,0.3)] transition-all font-mono text-sm"
                />
                {form.formState.errors.cookie && (
                  <p className="text-red-500 text-xs font-mono">
                    {form.formState.errors.cookie.message}
                  </p>
                )}
              </div>

              <NeonButton
                type="submit"
                disabled={isLoading}
                className="w-full bg-red-500/10 border-red-500 text-red-500 hover:bg-red-500 hover:text-black"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                    Removendo...
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2 inline" />
                    REMOVER TODOS OS AMIGOS
                  </>
                )}
              </NeonButton>
            </form>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/80 border-2 border-green-500 p-8 rounded-lg text-center shadow-[0_0_30px_rgba(34,197,94,0.3)]"
          >
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500 animate-pulse">
              <Users className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-green-500 mb-2">
              {result.message}
            </h2>
            <p className="text-green-500/60 mb-6">
              {result.removed} amigo(s) foram removidos com sucesso.
            </p>
            <NeonButton
              onClick={() => setResult(null)}
              className="bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
            >
              Remover Mais Amigos
            </NeonButton>
          </motion.div>
        )}
      </div>
    </div>
  );
}
