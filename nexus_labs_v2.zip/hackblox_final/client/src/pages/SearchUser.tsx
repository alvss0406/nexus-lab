import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Search, ArrowLeft, Loader2, Download } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  username: z.string().min(1, "Username é obrigatório"),
});

type FormValues = z.infer<typeof formSchema>;

interface UserData {
  id: string;
  name: string;
  displayName: string;
  description: string;
  created: string;
  isBanned: boolean;
  externalAppDisplayName: string | null;
  hasVerifiedBadge: boolean;
}

export default function SearchUser() {
  const [isLoading, setIsLoading] = useState(false);
  const [userResult, setUserResult] = useState<UserData | null>(null);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `/api/roblox/search-user/${encodeURIComponent(data.username)}`
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Usuário não encontrado");
      }

      const user = await response.json();
      setUserResult(user);

      toast({
        title: "Usuário Encontrado!",
        description: `${user.displayName} (${user.name})`,
      });
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao buscar usuário",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const downloadPDF = () => {
    if (!userResult) return;

    const pdfContent = `
NEXUS BEAMS X - USER REPORT
============================

USER INFORMATION
================
Name: ${userResult.name}
Display Name: ${userResult.displayName}
User ID: ${userResult.id}
Created: ${userResult.created}
Status: ${userResult.isBanned ? "BANNED" : "ACTIVE"}
Verified: ${userResult.hasVerifiedBadge ? "Yes" : "No"}

DESCRIPTION
===========
${userResult.description || "No description"}

EXTERNAL INFO
=============
External App: ${userResult.externalAppDisplayName || "None"}

Generated: ${new Date().toLocaleString()}
    `;

    const element = document.createElement("a");
    element.setAttribute(
      "href",
      "data:text/plain;charset=utf-8," + encodeURIComponent(pdfContent)
    );
    element.setAttribute("download", `${userResult.name}_report.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    toast({
      title: "Download Iniciado",
      description: "Relatório baixado com sucesso",
    });
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(34, 197, 94, .3) 25%, rgba(34, 197, 94, .3) 26%, transparent 27%, transparent 74%, rgba(34, 197, 94, .3) 75%, rgba(34, 197, 94, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-3xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-green-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-green-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="SEARCH USER"
              className="text-3xl md:text-4xl font-black text-green-500 text-glow"
            />
            <p className="text-green-500/60 text-sm mt-1">
              Busque informações de usuários do Roblox
            </p>
          </div>
        </div>

        {/* Search Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-black/80 border-2 border-green-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(34,197,94,0.2)] mb-6"
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-green-500 uppercase tracking-wider">
                Nome de Usuário
              </label>
              <div className="flex gap-2">
                <input
                  {...form.register("username")}
                  placeholder="Ex: Roblox"
                  className="flex-1 bg-green-900/10 border-2 border-green-500/30 rounded px-4 py-3 text-green-400 placeholder:text-green-500/20 focus:outline-none focus:border-green-500 focus:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all font-mono"
                />
                <NeonButton
                  type="submit"
                  disabled={isLoading}
                  className="bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black px-6"
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4" />
                  )}
                </NeonButton>
              </div>
              {form.formState.errors.username && (
                <p className="text-red-500 text-xs font-mono">
                  {form.formState.errors.username.message}
                </p>
              )}
            </div>
          </form>
        </motion.div>

        {/* User Result */}
        {userResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-green-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(34,197,94,0.2)]"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  Username
                </p>
                <p className="text-green-400 font-bold text-lg">
                  {userResult.name}
                </p>
              </div>
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  Display Name
                </p>
                <p className="text-green-400 font-bold text-lg">
                  {userResult.displayName}
                </p>
              </div>
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  User ID
                </p>
                <p className="text-green-400 font-bold font-mono">
                  {userResult.id}
                </p>
              </div>
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  Status
                </p>
                <p
                  className={`font-bold ${
                    userResult.isBanned ? "text-red-400" : "text-green-400"
                  }`}
                >
                  {userResult.isBanned ? "BANIDO" : "ATIVO"}
                </p>
              </div>
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  Criado em
                </p>
                <p className="text-green-400 font-bold">
                  {new Date(userResult.created).toLocaleDateString()}
                </p>
              </div>
              <div>
                <p className="text-green-500/60 text-xs uppercase font-bold">
                  Verificado
                </p>
                <p className="text-green-400 font-bold">
                  {userResult.hasVerifiedBadge ? "✅ Sim" : "❌ Não"}
                </p>
              </div>
            </div>

            {userResult.description && (
              <div className="mb-6 p-4 bg-green-900/10 border border-green-500/30 rounded">
                <p className="text-green-500/60 text-xs uppercase font-bold mb-2">
                  Descrição
                </p>
                <p className="text-green-400 text-sm">{userResult.description}</p>
              </div>
            )}

            <NeonButton
              onClick={downloadPDF}
              className="w-full bg-green-500/10 border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
            >
              <Download className="w-4 h-4 mr-2 inline" />
              DOWNLOAD RELATÓRIO
            </NeonButton>
          </motion.div>
        )}
      </div>
    </div>
  );
}
