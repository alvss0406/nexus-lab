import { motion } from "framer-motion";
import { BookOpen, Send, CheckCircle2 } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDiscordNickSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Tutorials() {
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();
  
  const form = useForm({
    resolver: zodResolver(insertDiscordNickSchema),
    defaultValues: {
      username: "",
      ticketCode: localStorage.getItem("auth_ticket") || ""
    }
  });

  const onSubmit = async (data: any) => {
    try {
      await apiRequest("POST", "/api/discord-nicks", data);
      setSubmitted(true);
      toast({
        title: "Sucesso!",
        description: "Seu nick foi enviado para análise.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível enviar seu nick.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4 mb-12">
          <BookOpen className="w-10 h-10 text-primary" />
          <h1 className="text-3xl font-display uppercase tracking-widest text-glow">Acesso ao Discord</h1>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card/30 border border-primary/20 p-8 rounded-xl space-y-6"
        >
          <div className="p-4 bg-primary/10 border border-primary/30 rounded-lg">
            <p className="text-xs text-primary uppercase font-bold mb-2 text-glow">Link do Servidor:</p>
            <a 
              href="https://discord.gg/D4dCxMvfV3" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 transition-colors break-all text-sm underline"
            >
              https://discord.gg/D4dCxMvfV3
            </a>
          </div>

          <div className="space-y-2 pt-4 border-t border-primary/10">
            <h2 className="text-xl font-display text-white text-glow">Solicitar Convite VIP</h2>
            <p className="text-sm text-muted-foreground">
              Se preferir, insira o seu usuário do Discord abaixo para um convite direto.
            </p>
          </div>

          {!submitted ? (
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs uppercase text-primary font-bold">Seu Usuário do Discord</label>
                <input
                  {...form.register("username")}
                  placeholder="ex: hacker_blox#0000"
                  className="w-full bg-black border border-primary/30 p-3 rounded text-white focus:border-primary outline-none transition-all"
                  data-testid="input-discord-username"
                />
                {form.formState.errors.username && (
                  <p className="text-red-500 text-xs">{form.formState.errors.username.message}</p>
                )}
              </div>
              <NeonButton variant="primary" className="w-full" type="submit" disabled={form.formState.isSubmitting}>
                <Send className="w-4 h-4 mr-2" /> ENVIAR PARA ADMS
              </NeonButton>
            </form>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 bg-primary/10 rounded-lg border border-primary/30">
              <CheckCircle2 className="w-12 h-12 text-primary mb-4 animate-pulse" />
              <p className="text-primary font-bold text-center uppercase tracking-tighter">Nick Enviado!</p>
              <p className="text-xs text-muted-foreground text-center mt-2">Aguarde o contato no seu Discord.</p>
            </div>
          )}
        </motion.div>

        <div className="text-center pt-8">
          <NeonButton onClick={() => window.location.href = "/"} variant="secondary">
            VOLTAR AO TERMINAL
          </NeonButton>
        </div>
      </div>
    </div>
  );
}
