import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Shield, ArrowLeft, Loader2, AlertTriangle, CheckCircle2 } from "lucide-react";
import { NeonButton } from "@/components/NeonButton";
import { GlitchText } from "@/components/GlitchText";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  cookie: z.string().min(10, "Cookie deve ter pelo menos 10 caracteres"),
});

type FormValues = z.infer<typeof formSchema>;

interface BypassResult {
  ageChanged: boolean;
  emailInvalidated: boolean;
  phoneInvalidated: boolean;
  message: string;
}

export default function AccountBypass() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<BypassResult | null>(null);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cookie: localStorage.getItem("roblox_cookie") || "",
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/roblox/account-bypass", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookie: data.cookie }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao fazer bypass");
      }

      const bypassResult = await response.json();
      setResult(bypassResult);

      toast({
        title: "Bypass Executado!",
        description: bypassResult.message,
      });
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message || "Falha ao fazer bypass",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-purple-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-purple-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="ACCOUNT BYPASS"
              className="text-3xl md:text-4xl font-black text-purple-500 text-glow"
            />
            <p className="text-purple-500/60 text-sm mt-1">
              Modifique configurações da conta
            </p>
          </div>
        </div>

        {/* Warning */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-purple-900/20 border-2 border-purple-500/30 p-4 rounded-lg mb-6 flex gap-3"
        >
          <AlertTriangle className="w-5 h-5 text-purple-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-purple-500 font-bold text-sm">⚠️ Operação Avançada</p>
            <p className="text-purple-500/60 text-xs mt-1">
              Esta ferramenta tenta modificar: Idade (para &lt;13), Email e Telefone da conta.
            </p>
          </div>
        </motion.div>

        {/* Form or Result */}
        {!result ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black/80 border-2 border-purple-500/30 p-8 rounded-lg shadow-[0_0_30px_rgba(168,85,247,0.2)]"
          >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-purple-500 uppercase tracking-wider">
                  .ROBLOSECURITY Cookie
                </label>
                <textarea
                  {...form.register("cookie")}
                  placeholder="Cole seu .ROBLOSECURITY aqui..."
                  className="w-full h-24 bg-purple-900/10 border-2 border-purple-500/30 rounded px-4 py-3 text-purple-400 placeholder:text-purple-500/20 focus:outline-none focus:border-purple-500 focus:shadow-[0_0_15px_rgba(168,85,247,0.3)] transition-all font-mono text-sm"
                />
                {form.formState.errors.cookie && (
                  <p className="text-red-500 text-xs font-mono">
                    {form.formState.errors.cookie.message}
                  </p>
                )}
              </div>

              <NeonButton
                type="submit"
                disabled={isLoading}
                className="w-full bg-purple-500/10 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-black"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin inline" />
                    Executando Bypass...
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4 mr-2 inline" />
                    EXECUTAR BYPASS
                  </>
                )}
              </NeonButton>
            </form>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            {/* Results Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Age */}
              <div
                className={`p-4 rounded-lg border-2 ${
                  result.ageChanged
                    ? "bg-green-900/20 border-green-500"
                    : "bg-red-900/20 border-red-500"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {result.ageChanged ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  )}
                  <p
                    className={`font-bold text-sm ${
                      result.ageChanged ? "text-green-500" : "text-red-500"
                    }`}
                  >
                    Idade
                  </p>
                </div>
                <p
                  className={`text-xs ${
                    result.ageChanged ? "text-green-500/60" : "text-red-500/60"
                  }`}
                >
                  {result.ageChanged ? "Alterada para <13" : "Falhou"}
                </p>
              </div>

              {/* Email */}
              <div
                className={`p-4 rounded-lg border-2 ${
                  result.emailInvalidated
                    ? "bg-green-900/20 border-green-500"
                    : "bg-red-900/20 border-red-500"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {result.emailInvalidated ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  )}
                  <p
                    className={`font-bold text-sm ${
                      result.emailInvalidated ? "text-green-500" : "text-red-500"
                    }`}
                  >
                    Email
                  </p>
                </div>
                <p
                  className={`text-xs ${
                    result.emailInvalidated ? "text-green-500/60" : "text-red-500/60"
                  }`}
                >
                  {result.emailInvalidated ? "Invalidado" : "Falhou"}
                </p>
              </div>

              {/* Phone */}
              <div
                className={`p-4 rounded-lg border-2 ${
                  result.phoneInvalidated
                    ? "bg-green-900/20 border-green-500"
                    : "bg-red-900/20 border-red-500"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {result.phoneInvalidated ? (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  )}
                  <p
                    className={`font-bold text-sm ${
                      result.phoneInvalidated ? "text-green-500" : "text-red-500"
                    }`}
                  >
                    Telefone
                  </p>
                </div>
                <p
                  className={`text-xs ${
                    result.phoneInvalidated ? "text-green-500/60" : "text-red-500/60"
                  }`}
                >
                  {result.phoneInvalidated ? "Removido" : "Falhou"}
                </p>
              </div>
            </div>

            {/* Message */}
            <div className="bg-black/80 border-2 border-purple-500/30 p-6 rounded-lg">
              <p className="text-purple-400 text-sm font-mono">{result.message}</p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <NeonButton
                onClick={() => setResult(null)}
                className="flex-1 bg-purple-500/10 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-black"
              >
                Executar Novamente
              </NeonButton>
              <Link href="/dashboard" className="flex-1">
                <button className="w-full px-6 py-3 bg-purple-500/10 border-2 border-purple-500 text-purple-500 rounded hover:bg-purple-500 hover:text-black transition-all font-mono font-bold">
                  Voltar
                </button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
