import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, MessageCircle, Globe, Github, Twitter } from "lucide-react";
import { siDiscord } from "react-icons/si";
import { GlitchText } from "@/components/GlitchText";

export default function SocialNetworks() {
  const networks = [
    {
      name: "Discord",
      description: "Junte-se à nossa comunidade no Discord",
      icon: siDiscord,
      url: "https://discord.gg/nFnFVTY4QH",
      color: "from-blue-500 to-indigo-500",
      members: "1.2K+",
    },
    {
      name: "Website",
      description: "Visite nosso site oficial",
      icon: Globe,
      url: "#",
      color: "from-green-500 to-emerald-500",
      members: "Online",
    },
    {
      name: "GitHub",
      description: "Confira nossos projetos",
      icon: Github,
      url: "#",
      color: "from-gray-500 to-slate-500",
      members: "Open Source",
    },
    {
      name: "Twitter",
      description: "Siga nossas atualizações",
      icon: Twitter,
      url: "#",
      color: "from-cyan-500 to-blue-500",
      members: "Updates",
    },
  ];

  return (
    <div className="min-h-screen bg-black p-8 font-mono scanlines">
      {/* Background Decor */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(0deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(168, 85, 247, .3) 25%, rgba(168, 85, 247, .3) 26%, transparent 27%, transparent 74%, rgba(168, 85, 247, .3) 75%, rgba(168, 85, 247, .3) 76%, transparent 77%, transparent)",
          backgroundSize: "50px 50px",
        }}
      />

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <Link href="/dashboard">
            <button className="p-2 hover:bg-purple-500/20 rounded transition-all">
              <ArrowLeft className="w-6 h-6 text-purple-500" />
            </button>
          </Link>
          <div>
            <GlitchText
              text="NEXUS LABS"
              className="text-4xl md:text-5xl font-black text-purple-500 text-glow"
            />
            <p className="text-purple-500/60 text-sm mt-1">
              Nossas Redes Sociais
            </p>
          </div>
        </div>

        {/* Networks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {networks.map((network, index) => {
            const Icon = network.icon;
            return (
              <motion.a
                key={network.name}
                href={network.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="block"
              >
                <div className="bg-black/80 border-2 border-purple-500/30 p-8 rounded-lg hover:border-purple-500 transition-all shadow-[0_0_20px_rgba(168,85,247,0.1)] hover:shadow-[0_0_30px_rgba(168,85,247,0.3)] group h-full">
                  <div
                    className={`w-16 h-16 rounded-lg bg-gradient-to-br ${network.color} p-3 mb-4 group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-full h-full text-white" />
                  </div>

                  <h3 className="text-2xl font-bold text-purple-400 mb-2">
                    {network.name}
                  </h3>

                  <p className="text-purple-500/60 text-sm mb-4">
                    {network.description}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
                    <span className="text-xs text-purple-500/40 uppercase">
                      {network.members}
                    </span>
                    <span className="text-purple-500 text-sm font-bold">
                      →
                    </span>
                  </div>
                </div>
              </motion.a>
            );
          })}
        </div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-purple-900/20 border-2 border-purple-500/30 p-6 rounded-lg text-center"
        >
          <p className="text-purple-400 mb-4">
            Conecte-se com a comunidade NEXUS LABS e fique por dentro das últimas atualizações!
          </p>
          <p className="text-purple-500/60 text-sm">
            Junte-se a milhares de usuários que já confiam em nossas ferramentas.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
