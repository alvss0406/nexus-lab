import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GlitchTextProps {
  text: string;
  className?: string;
  as?: "h1" | "h2" | "h3" | "h4" | "span" | "div";
}

export function GlitchText({ text, className, as: Component = "h1" }: GlitchTextProps) {
  return (
    <div className="relative inline-block group">
      <Component 
        className={cn(
          "relative z-10 font-display uppercase tracking-widest", 
          className
        )}
      >
        {text}
      </Component>
      
      {/* Glitch Layer 1 - Red/Blue shift */}
      <Component 
        className={cn(
          "absolute top-0 left-0 -z-10 opacity-0 group-hover:opacity-70 group-hover:animate-glitch text-red-500 translate-x-[2px]", 
          className
        )}
        aria-hidden="true"
      >
        {text}
      </Component>
      
      {/* Glitch Layer 2 - Cyan shift */}
      <Component 
        className={cn(
          "absolute top-0 left-0 -z-10 opacity-0 group-hover:opacity-70 group-hover:animate-glitch text-cyan-500 -translate-x-[2px] animation-delay-200", 
          className
        )}
        style={{ animationDirection: "reverse" }}
        aria-hidden="true"
      >
        {text}
      </Component>
    </div>
  );
}
