import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface NeonButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger";
  isLoading?: boolean;
}

export const NeonButton = forwardRef<HTMLButtonElement, NeonButtonProps>(
  ({ className, children, variant = "primary", isLoading, disabled, ...props }, ref) => {
    
    const variants = {
      primary: "border-primary text-primary hover:bg-primary/10 shadow-[0_0_15px_rgba(168,85,247,0.3)] hover:shadow-[0_0_25px_rgba(168,85,247,0.5)]",
      secondary: "border-secondary text-secondary hover:bg-secondary/10 shadow-[0_0_15px_rgba(34,197,94,0.3)] hover:shadow-[0_0_25px_rgba(34,197,94,0.5)]",
      danger: "border-destructive text-destructive hover:bg-destructive/10 shadow-[0_0_15px_rgba(239,68,68,0.3)] hover:shadow-[0_0_25px_rgba(239,68,68,0.5)]",
    };

    return (
      <motion.button
        ref={ref}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        disabled={disabled || isLoading}
        className={cn(
          "relative px-8 py-3 rounded-md font-display font-bold uppercase tracking-widest border-2 transition-all duration-300 backdrop-blur-sm",
          "disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none disabled:hover:bg-transparent",
          variants[variant],
          className
        )}
        {...props}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            PROCESSING...
          </span>
        ) : (
          children
        )}
      </motion.button>
    );
  }
);
NeonButton.displayName = "NeonButton";
