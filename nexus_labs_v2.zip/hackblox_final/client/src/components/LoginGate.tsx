interface LoginGateProps {
  children: React.ReactNode;
}

export function LoginGate({ children }: LoginGateProps) {
  // Sem autenticação - acesso direto
  return <>{children}</>;
}
