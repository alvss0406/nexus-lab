import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal as TerminalIcon, ShieldAlert, Wifi, Database, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

interface LogEntry {
  id: string;
  text: string;
  type: "info" | "success" | "warning" | "error";
  delay: number; // ms to wait before showing next log
}

interface TerminalWindowProps {
  logs: LogEntry[];
  onComplete?: () => void;
  title?: string;
}

export function TerminalWindow({ logs, onComplete, title = "HACKBLOX_TERMINAL_V2.0.4" }: TerminalWindowProps) {
  const [visibleLogs, setVisibleLogs] = useState<LogEntry[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let currentIndex = 0;
    let isMounted = true;

    const processLogs = async () => {
      while (currentIndex < logs.length && isMounted) {
        const log = logs[currentIndex];
        
        // Add log
        setVisibleLogs(prev => [...prev, log]);
        
        // Update progress bar
        setProgress(Math.round(((currentIndex + 1) / logs.length) * 100));

        // Scroll to bottom
        if (scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }

        // Wait for delay
        await new Promise(r => setTimeout(r, log.delay));
        
        currentIndex++;
      }

      if (isMounted && onComplete) {
        onComplete();
      }
    };

    processLogs();

    return () => { isMounted = false; };
  }, [logs]);

  // Auto-scroll effect whenever visibleLogs changes
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [visibleLogs]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      className="w-full max-w-2xl bg-black/90 border border-secondary/50 rounded-lg overflow-hidden shadow-[0_0_30px_rgba(34,197,94,0.2)] font-mono"
    >
      {/* Header Bar */}
      <div className="bg-secondary/10 px-4 py-2 border-b border-secondary/30 flex items-center justify-between">
        <div className="flex items-center gap-2 text-secondary text-xs font-bold tracking-wider">
          <TerminalIcon className="w-4 h-4" />
          {title}
        </div>
        <div className="flex gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500/50" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
          <div className="w-3 h-3 rounded-full bg-green-500/50" />
        </div>
      </div>

      {/* Content Area */}
      <div 
        ref={scrollRef}
        className="p-6 h-80 overflow-y-auto scrollbar-hide text-sm md:text-base space-y-2 font-mono relative"
      >
        {/* Scanline overlay inside terminal only */}
        <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%)] bg-[length:100%_4px] opacity-50 z-10" />

        <AnimatePresence>
          {visibleLogs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className={cn(
                "flex items-center gap-3 relative z-20",
                log.type === "success" && "text-secondary",
                log.type === "warning" && "text-yellow-500",
                log.type === "error" && "text-destructive font-bold",
                log.type === "info" && "text-secondary/70"
              )}
            >
              <span className="opacity-50 text-xs">[{new Date().toLocaleTimeString()}]</span>
              
              {log.type === "success" && <Lock className="w-4 h-4" />}
              {log.type === "warning" && <Wifi className="w-4 h-4 animate-pulse" />}
              {log.type === "error" && <ShieldAlert className="w-4 h-4" />}
              {log.type === "info" && <span className="w-4 h-4 block">›</span>}
              
              <span>{log.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {progress < 100 && (
          <motion.div 
            animate={{ opacity: [0, 1, 0] }}
            transition={{ repeat: Infinity, duration: 0.8 }}
            className="w-3 h-5 bg-secondary inline-block align-middle ml-2"
          />
        )}
      </div>

      {/* Footer Status */}
      <div className="px-4 py-3 bg-secondary/5 border-t border-secondary/20 flex items-center justify-between text-xs text-secondary/60">
        <div className="flex items-center gap-2">
          <Database className="w-3 h-3" />
          <span>STATUS: {progress < 100 ? "INTRUSION IN PROGRESS" : "ACCESS GRANTED"}</span>
        </div>
        <div className="w-1/3 h-1.5 bg-secondary/20 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-secondary shadow-[0_0_10px_rgba(34,197,94,0.8)]"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </motion.div>
  );
}
