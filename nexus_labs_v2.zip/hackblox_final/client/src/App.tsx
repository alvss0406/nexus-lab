import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import PrankView from "@/pages/PrankView";
import Admin from "@/pages/Admin";
import Tutorials from "@/pages/Tutorials";
import CookieLogin from "@/pages/CookieLogin";
import CookieAccess from "@/pages/CookieAccess";
import RemoveFriends from "@/pages/RemoveFriends";
import SearchUser from "@/pages/SearchUser";
import AuthAuthenticator from "@/pages/AuthAuthenticator";
import CookieRefresher from "@/pages/CookieRefresher";
import AccountBypass from "@/pages/AccountBypass";
import SocialNetworks from "@/pages/SocialNetworks";
import Dashboard from "@/pages/Dashboard";
import { LoginGate } from "@/components/LoginGate";

function Router() {
  return (
    <LoginGate>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/cookie-login" component={CookieLogin} />
        <Route path="/cookie-access" component={CookieAccess} />
        <Route path="/remove-friends" component={RemoveFriends} />
        <Route path="/search-user" component={SearchUser} />
        <Route path="/auth-authenticator" component={AuthAuthenticator} />
        <Route path="/cookie-refresher" component={CookieRefresher} />
        <Route path="/account-bypass" component={AccountBypass} />
        <Route path="/social-networks" component={SocialNetworks} />
        <Route path="/hack/:id" component={PrankView} />
        <Route path="/admin" component={Admin} />
        <Route path="/tutorials" component={Tutorials} />
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </LoginGate>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
