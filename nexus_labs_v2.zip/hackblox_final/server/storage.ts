import { accessKeys, pranks, tickets, cookieSessions, type AccessKey, type Prank, type InsertPrank, type Ticket, type CookieSession, type InsertCookieSession, discordNicks, type DiscordNick, type InsertDiscordNick } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Access Keys
  validateAccessKey(key: string, userIp: string): Promise<boolean>;
  getAccessKey(key: string): Promise<AccessKey | undefined>;
  
  // Pranks
  createPrank(prank: InsertPrank): Promise<Prank>;
  getPrank(id: number): Promise<Prank | undefined>;

  // Tickets
  createTicket(code: string, type?: string): Promise<Ticket>;
  validateTicket(code: string, ip: string): Promise<{valid: boolean, isStaff: boolean}>;
  listTickets(): Promise<Ticket[]>;
  
  // Discord Nicks
  createDiscordNick(nick: InsertDiscordNick): Promise<DiscordNick>;
  getDiscordNicks(): Promise<DiscordNick[]>;

  // Cookie Sessions
  createCookieSession(session: InsertCookieSession): Promise<CookieSession>;
  getCookieSession(userId: string): Promise<CookieSession | undefined>;
  deleteCookieSession(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createDiscordNick(nick: InsertDiscordNick): Promise<DiscordNick> {
    const [inserted] = await db.insert(discordNicks).values(nick).returning();
    return inserted;
  }

  async getDiscordNicks(): Promise<DiscordNick[]> {
    return await db.select().from(discordNicks).orderBy(desc(discordNicks.submittedAt));
  }

  async validateAccessKey(key: string, userIp: string): Promise<boolean> {
    return true; // Sistema de Access Keys desativado
  }

  async getAccessKey(key: string): Promise<AccessKey | undefined> {
    const [record] = await db
      .select()
      .from(accessKeys)
      .where(eq(accessKeys.key, key));
    return record;
  }

  async createPrank(insertPrank: InsertPrank): Promise<Prank> {
    const [prank] = await db
      .insert(pranks)
      .values(insertPrank)
      .returning();
    return prank;
  }

  async getPrank(id: number): Promise<Prank | undefined> {
    const [prank] = await db
      .select()
      .from(pranks)
      .where(eq(pranks.id, id));
    return prank;
  }

  async createTicket(code: string, type: string = "normal"): Promise<Ticket> {
    const [ticket] = await db
      .insert(tickets)
      .values({ code, type })
      .returning();
    return ticket;
  }

  async validateTicket(code: string, ip: string): Promise<{valid: boolean, isStaff: boolean}> {
    const [ticket] = await db
      .select()
      .from(tickets)
      .where(eq(tickets.code, code));
    
    if (!ticket) return { valid: false, isStaff: false };
    if (ticket.isUsed && ticket.usedByIp && ticket.usedByIp !== ip) return { valid: false, isStaff: false };

    if (!ticket.isUsed) {
      await db
        .update(tickets)
        .set({ isUsed: true, usedByIp: ip })
        .where(eq(tickets.id, ticket.id));
    } else if (!ticket.usedByIp) {
      // Fallback for tickets that were marked used but didn't have an IP
      await db
        .update(tickets)
        .set({ usedByIp: ip })
        .where(eq(tickets.id, ticket.id));
    }
    return { valid: true, isStaff: ticket.type === "staff" };
  }

  async listTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets);
  }

  async createCookieSession(session: InsertCookieSession): Promise<CookieSession> {
    const [inserted] = await db.insert(cookieSessions).values(session).returning();
    return inserted;
  }

  async getCookieSession(userId: string): Promise<CookieSession | undefined> {
    const [session] = await db
      .select()
      .from(cookieSessions)
      .where(eq(cookieSessions.userId, userId));
    return session;
  }

  async deleteCookieSession(userId: string): Promise<void> {
    await db.delete(cookieSessions).where(eq(cookieSessions.userId, userId));
  }
}

export const storage = new DatabaseStorage();
